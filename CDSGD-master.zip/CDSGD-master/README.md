# CDSGD
This is a placeholder repository for Consensus Based Distributed Stochastic Gradient Descent. For more details, please see the paper: 
**[Collaborative Deep Learning in Fixed Topology Networks][1]**  
Zhanhong Jiang, Aditya Balu, Chinmay Hegde, Soumik Sarkar

### Usage


### License

BSD

[1]:https://arxiv.org/abs/1706.07880
[2]:http://scslab.me.iastate.edu/index.html

